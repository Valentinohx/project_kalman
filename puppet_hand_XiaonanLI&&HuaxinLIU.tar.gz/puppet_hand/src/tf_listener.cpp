#include <ros/ros.h>
#include <tf/transform_listener.h>
#include <baxter_core_msgs/SolvePositionIK.h>
#include <std_msgs/Float64.h>
#include <sensor_msgs/JointState.h>
#include <baxter_core_msgs/JointCommand.h>

int main(int argc, char** argv) {
    ros::init(argc, argv, "tf_listener");
    ros::NodeHandle nh;
    
    tf::TransformListener listener;
    ros::Rate rate(10.0);
    
    ros::Publisher pub_command = nh.advertise<baxter_core_msgs::JointCommand>("/robot/limb/left/joint_command", 1);
         
    ros::ServiceClient client =
			nh.serviceClient<baxter_core_msgs::SolvePositionIK>("/ExternalTools/left/PositionKinematicsNode/IKService");
    
    while(ros::ok()) {
		ros::spinOnce();
		
        tf::StampedTransform transform;
        try {
            listener.lookupTransform("base", "gr07_left_hand", ros::Time(0), transform); 
        catch(tf::TransformException &ex) {
            ROS_ERROR("%s", ex.what());
            ros::Duration(1).sleep();
            continue;
        }
		
			baxter_core_msgs::SolvePositionIK srv_msg;
			
			srv_msg.request.seed_mode=2;
			    
		//service request
		geometry_msgs::PoseStamped pos_msg; // geometry_msgs::PoseStamped is an object
		
		//set posiition
		pos_msg.pose.position.x =  transform.getOrigin().getX();
		pos_msg.pose.position.y =  transform.getOrigin().getY();
		pos_msg.pose.position.z =  transform.getOrigin().getZ();
	    // set orientation
		pos_msg.pose.orientation.x = transform.getRotation().getAxis().getX();
		pos_msg.pose.orientation.y = transform.getRotation().getAxis().getY();
		pos_msg.pose.orientation.z = transform.getRotation().getAxis().getZ();
		pos_msg.pose.orientation.w = transform.getRotation().getW();
		
		pos_msg.header.stamp = ros::Time::now();   //used to communicate timestamped data ?
		pos_msg.header.frame_id = "/base";
		//
		srv_msg.request.pose_stamp.push_back(pos_msg);
		
		//call inverse geometry service 
		if( !client.exists() ){
			ROS_INFO("No service.");
			continue ;
		}
		
		if( !client.call(srv_msg) ){
			ROS_INFO("Incorrect call to service.");
			continue ;
		}
		
		 baxter_core_msgs::JointCommand msg_command;
		 
		//service response
		//if (srv_msg.response.result_type[0] != srv_msg.response.RESULT_INVALID)
		if (srv_msg.response.result_type[0] != 0)
		//if (srv_msg.response.isValid[0])
		{ 
			ROS_INFO("Found solution.");
                  msg_command.mode = msg_command.POSITION_MODE;
            
                  for (int i = 0; i <= 6; i ++ )
                  {
                  msg_command.names.push_back(srv_msg.response.joints[0].name[i]);
                  msg_command.command.push_back(srv_msg.response.joints[0].position[i]);
                  }
                  pub_command.publish(msg_command);//Publish the command
		 }
		 else
		 {
			 ROS_INFO("no solution found");
		 }           
    }
    rate.sleep();
    return 0;
}





