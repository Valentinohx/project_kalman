#include <ros/ros.h>
#include <tf/transform_broadcaster.h>


int main(int argc, char** argv){
	  ros::init(argc, argv, "tf_broadcaster");
	  
	  ros::NodeHandle node;
	  
	  // Define transformation here, as it is constant.
  	  
	  tf::Transform transform;
	  
      transform.setOrigin( tf::Vector3(0, 0, 0.25) );
      tf::Quaternion q;
      q.setRPY(0, M_PI, 0);
      transform.setRotation(q);
	  tf::TransformBroadcaster br;
	  
	  ros::Rate rate(20);
	  while (ros::ok())
	  {
		ros::spinOnce();
			 br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "/right_hand", "gr07_left_hand"));
		
		rate.sleep();
	  } 
	  
   }




