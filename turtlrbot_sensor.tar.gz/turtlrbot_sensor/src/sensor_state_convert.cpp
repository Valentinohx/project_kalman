/*
    sensor_state_convert.cpp
    created at 2018-05-15
    Xiao SHI && Huaxin LIU
    objective: read the external sensor informations and transform it to binary

    Subscribe : /mobile_base/sensors/core
    Publish   : /capteur_carrelage
*/

#include "ros/ros.h"
#include <kobuki_msgs/SensorState.h>
#include <std_msgs/Bool.h>
#include <std_msgs/Int8MultiArray.h>

using namespace std;

//Publishers
ros::Publisher publisher_capteur;

//sensor limites;
const int sensor_threshold = 2000;

std_msgs::Int8MultiArray etat_capteur;

//Callback de mesure
void conversionCallback(kobuki_msgs::SensorState msg_state)
{
    etat_capteur.data[0] = msg_state.bottom[2] > sensor_threshold ? 1 : 0;   //left sensor
    etat_capteur.data[1] = msg_state.bottom[0] > sensor_threshold ? 1 : 0;   //right sensor

    publisher_capteur.publish(etat_capteur);   //publish all the sensor state at onece
}

int main(int argc, char **argv)
{
    //ROS Initialization
    ros::init(argc, argv, "sensor_state_convert");
    ROS_INFO("Node conversion_capteur_node connected to roscore");
    ros::NodeHandle nh;
    //Subscribing
    ROS_INFO("Subscribing to topics\n");
    ros::Subscriber subscriber_capteur = nh.subscribe<kobuki_msgs::SensorState>("/mobile_base/sensors/core" , 1, conversionCallback);

    //Publishing
    publisher_capteur = nh.advertise< std_msgs::Int8MultiArray >("/capteur_carrelage", 1);

    while (ros::ok())
    {
        ros::spinOnce();
    }

    return 0;
}
